import React from "react";
import qr from "./paymentsImage/bar-code.png";
import TextField from "@mui/material/TextField";
// import Box from "@mui/material/Box";
// import InputLabel from "@mui/material/InputLabel";
// import MenuItem from "@mui/material/MenuItem";
// import FormControl from "@mui/material/FormControl";
// import Select, { SelectChangeEvent } from "@mui/material/Select";

import Select from "@mui/joy/Select";
import Option from "@mui/joy/Option";

import "./PaymentsPage.css";

function PaymentsPage() {
  const [category, setCategory] = React.useState("");

  return (
    <>
      <div className="outer-contaer">
        <div className="hero-text-payments">&lt; Payment &gt;</div>
        <div className="container-main-account">
          <div className="account-details-title">Account Details</div>
          <div className="account-details">
            <div className="clg-acc-detail">
              <div className="acc-holder">
                {" "}
                <span style={{ fontWeight: "bold" }}> A/C Holder : </span>
                Chaibasa Engineering College
              </div>
              <div className="acc-type">
                <span style={{ fontWeight: "bold" }}> A/C Type : </span>Current
                Account
              </div>
              <div className="acc-branch">
                <span style={{ fontWeight: "bold" }}> Branch Name : </span>Gen
                Next Br. Salt Lake
              </div>
              <div className="acc-no">
                <span style={{ fontWeight: "bold" }}> A/C Number : </span>
                32210200000213
              </div>
              <div className="acc-ifsc">
                <span style={{ fontWeight: "bold" }}> IFSC Code : </span>
                BARB0GENSAL
              </div>
            </div>
            <div className="or">
              <div className="or-content">or</div>
            </div>
            <div className="acc-qr">
              <div className="qr">
                <img src={qr} alt="qr-code" />
              </div>
            </div>
          </div>
        </div>

        <div className="form-upload my-5">
          <form className="payment-upload-form p-3 rounded" method="post">
            <div className="payment-upload-head my-3">
              <h3>Payment Form</h3>
            </div>
            <table className="table payment-upload-sec">
              <tbody className="payment-upload-box">
                <tr className="sec-one">
                  <td className="sec-one-inner">
                    <TextField
                      className="w-100"
                      variant="outlined"
                      type="text"
                      name="name"
                      id="outlined-basic"
                      label="Your Name"
                      //   value={paymentname.name}
                      //   onChange={handleInputs}
                    />
                  </td>
                  <td className="sec-one-inner">
                    <TextField
                      className="w-100"
                      variant="outlined"
                      type="text"
                      name="subject"
                      id="outlined-basic"
                      label="Student ID"
                      //   value={paymentname.subject}
                      //   onChange={handleInputs}
                    />
                  </td>
                  <td className="sec-one-inner">
                    <TextField
                      className="w-100"
                      variant="outlined"
                      type="text"
                      name="year"
                      id="outlined-basic"
                      label="Semester"
                      //   value={paymentname.year}
                      //   onChange={handleInputs}
                    />
                  </td>
                </tr>
                <tr className="sec-tow">
                  <td className="sec-two-inner">
                    <TextField
                      className="w-100"
                      variant="outlined"
                      type="date"
                      name="name"
                      id="outlined-basic"
                      label=""
                      //   value={paymentname.name}
                      //   onChange={handleInputs}
                    />
                  </td>
                  <td className="sec-two-inner">
                    <TextField
                      className="w-100"
                      variant="outlined"
                      type="text"
                      name="subject"
                      id="outlined-basic"
                      label="UTR No"
                      //   value={paymentname.subject}
                      //   onChange={handleInputs}
                    />
                  </td>
                  <td className="sec-two-inner">
                    <Select
                      defaultValue=""
                      placeholder="Category"
                      sx={{
                        width: "100%",
                        height: 50,
                      }}
                    >
                      <Option value="free-ur-ews">Free UR/EWS</Option>
                      <Option value="free-sc">Free SC</Option>
                      <Option value="free-st">Free ST</Option>
                      <Option value="free-bci-bcii">Fr ee BC_I/BC_II</Option>
                      <Option value="payment-seat">Payment Seat</Option>
                      <Option value="iq-seat">IQ Seat</Option>
                      <Option value="tfw">TFW</Option>
                    </Select>
                  </td>
                </tr>
                <tr className="sec-three">
                  <td className="sec-three-inner">
                    <TextField
                      className="w-100"
                      variant="outlined"
                      type="text"
                      name="name"
                      id="outlined-basic"
                      label="Amount"
                      //   value={paymentname.name}
                      //   onChange={handleInputs}
                    />
                  </td>
                  <td className="sec-three-inner">
                    <TextField
                      className="w-100"
                      variant="outlined"
                      type="link"
                      name="name"
                      id="outlined-basic"
                      label="Link"
                      //   value={paymentname.name}
                      //   onChange={handleInputs}
                    />
                  </td>

                  <td>
                    <input
                      className="px-5 w-100"
                      id="payment-form-button"
                      type="submit"
                      value="Submit"
                      //   onClick={PostData}
                    ></input>
                  </td>
                </tr>
              </tbody>
            </table>
          </form>
        </div>
      </div>
    </>
  );
}

export default PaymentsPage;
